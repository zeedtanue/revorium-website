(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6358:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./styles/Footer.module.css
var Footer_module = __webpack_require__(7656);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Footer.js






function Footer() {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (Footer_module_default()).container,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
      className: (`footer`, (Footer_module_default()).footer),
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "columns",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "column is-3 is-offset",
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              style: {
                fontSize: 22,
                fontWeight: 'bold'
              },
              children: " Revorium"
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. "
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "column is-2 is-offset-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: "/service",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                style: {
                  fontSize: 22,
                  fontWeight: 'bold',
                  paddingBottom: 10
                },
                className: (Footer_module_default()).text,
                children: "Our Service"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: "/service",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: "Software Developmen"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: "/our-products",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: "Fair Ride"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "column is-2 is-offset-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: "/company",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                style: {
                  fontSize: 22,
                  fontWeight: 'bold',
                  paddingBottom: 10
                },
                className: (Footer_module_default()).text,
                children: "Our Company"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: "/company",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: "Info"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "column is-2 is-offset-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              style: {
                fontSize: 22,
                fontWeight: 'bold'
              },
              children: "Address"
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "2972 Westheimer Rd. Santa Ana, Illinois 85486 "
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "(270) 555-0117"
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "tanya.hill@example.com"
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mgt-medium"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mgt-medium"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          style: {
            marginTop: 70
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "column is-5 is-offset",
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: "\xA9 2022 Revorium. A European IT company. All rights  served."
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "column is-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "icon has-text-info",
              children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                className: "fas fa-info-circle"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "icon has-text-success",
              children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                className: "fas fa-check-square"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "icon has-text-warning",
              children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                className: "fas fa-exclamation-triangle"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "icon has-text-danger",
              children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                className: "fas fa-ban"
              })
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("script", {
        src: "../js/bulma.js"
      })]
    })
  });
}

/* harmony default export */ const components_Footer = (Footer);
;// CONCATENATED MODULE: ./components/NavBar.js





const NavBar = () => {
  const {
    0: isActive,
    1: setisActive
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    style: {
      minHeight: 70,
      display: 'flex'
    },
    children: /*#__PURE__*/jsx_runtime_.jsx("nav", {
      className: "container navbar is-tranparent is-bold",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "navbar-brand",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            passHref: true,
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "navbar-item is-size-2 has-text-weight-bold",
              href: "../",
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                style: {
                  minHeight: 50,
                  maxWidth: 200
                },
                src: "/logoBig.png",
                alt: "Revorium logo",
                width: "268",
                height: "100"
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "navbar-burger burger",
            "data-target": "navbarExampleTransparentExample",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              onClick: () => {
                setisActive(!isActive);
              },
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {}), /*#__PURE__*/jsx_runtime_.jsx("span", {}), /*#__PURE__*/jsx_runtime_.jsx("span", {})]
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          id: "navbarExampleTransparentExample",
          className: `navbar-menu ${isActive ? "is-active" : ""}`,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "navbar-end",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: '/',
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => setisActive(false),
                style: {
                  fontSize: 14,
                  font: 'Nunito'
                },
                className: "navbar-item",
                children: "HOME"
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "navbar-item has-dropdown is-hoverable",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                passHref: true,
                href: '/service',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  onClick: () => setisActive(false),
                  style: {
                    fontSize: 14,
                    font: 'Nunito'
                  },
                  className: "navbar-link",
                  children: "SERVICE"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "navbar-dropdown",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                  passHref: true,
                  href: '/service',
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    onClick: () => setisActive(false),
                    style: {
                      fontSize: 14,
                      font: 'Nunito'
                    },
                    className: "navbar-item",
                    children: "Software Development"
                  })
                })
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "navbar-item has-dropdown is-hoverable",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                passHref: true,
                href: '/our-products',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  onClick: () => setisActive(false),
                  style: {
                    fontSize: 14,
                    font: 'Nunito'
                  },
                  className: "navbar-link",
                  href: "https://bulma.io/documentation/overview/start/",
                  children: "OUR PRODUCTS"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "navbar-dropdown",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                  passHref: true,
                  href: '/our-products',
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    onClick: () => setisActive(false),
                    style: {
                      fontSize: 14,
                      font: 'Nunito'
                    },
                    className: "navbar-item",
                    children: "Fair Ride"
                  })
                })
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: '/blog',
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => setisActive(false),
                style: {
                  fontSize: 14,
                  font: 'Nunito'
                },
                className: "navbar-item",
                children: "BLOG"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: '/company',
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => setisActive(false),
                style: {
                  fontSize: 14,
                  font: 'Nunito'
                },
                className: "navbar-item",
                children: "COMPANY"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              passHref: true,
              href: '/contact-us',
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: () => setisActive(false),
                style: {
                  fontSize: 14,
                  font: 'Nunito'
                },
                className: "navbar-item",
                children: "CONTACT US"
              })
            })]
          })
        })]
      })
    })
  });
};

/* harmony default export */ const components_NavBar = (NavBar);
;// CONCATENATED MODULE: ./components/Layout.js






const Layout = ({
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "content",
    children: [/*#__PURE__*/jsx_runtime_.jsx(components_NavBar, {}), children, /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
  });
};

/* harmony default export */ const components_Layout = (Layout);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
// EXTERNAL MODULE: ./styles/Loader.module.css
var Loader_module = __webpack_require__(3925);
var Loader_module_default = /*#__PURE__*/__webpack_require__.n(Loader_module);
;// CONCATENATED MODULE: ./components/Loader.js




const Loader = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (Loader_module_default()).loaderContainer,
    children: /*#__PURE__*/jsx_runtime_.jsx("img", {
      src: "/loader.svg"
    })
  });
};

/* harmony default export */ const components_Loader = (Loader);
;// CONCATENATED MODULE: ./pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function MyApp({
  Component,
  pageProps
}) {
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  router_default().events.on('routeChangeStart', url => {
    setLoading(true);
  });
  router_default().events.on('routeChangeComplete', url => {
    setLoading(false);
  });
  return /*#__PURE__*/jsx_runtime_.jsx(components_Layout, {
    children: loading ? /*#__PURE__*/jsx_runtime_.jsx(components_Loader, {}) : /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 7656:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Footer_container__iN3aW",
	"text": "Footer_text__TFiKo",
	"main": "Footer_main__LZSM_",
	"footer": "Footer_footer__Tl1eP",
	"title": "Footer_title__ZStl1",
	"description": "Footer_description__vL2pB",
	"code": "Footer_code__80PF2",
	"grid": "Footer_grid__VzJbh",
	"card": "Footer_card__RLUtm",
	"logo": "Footer_logo__PM82v"
};


/***/ }),

/***/ 3925:
/***/ ((module) => {

// Exports
module.exports = {
	"loaderContainer": "Loader_loaderContainer__E5uWD"
};


/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [206,676,664], () => (__webpack_exec__(6358)));
module.exports = __webpack_exports__;

})();