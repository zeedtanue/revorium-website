"use strict";
exports.id = 375;
exports.ids = [375];
exports.modules = {

/***/ 6375:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Button),
/* harmony export */   "H": () => (/* binding */ CardWide)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "StyledComponent__Button",
  componentId: "sc-ys5dtm-0"
})(["background-color:", ";width:164px;height:45px;color:", ";font-weight:bold;border:none;border-radius:.2rem;"], props => props.backgroundColor, props => props.color);
const CardWide = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "StyledComponent__CardWide",
  componentId: "sc-ys5dtm-1"
})(["background:#F8F8F8;border-radius:34px 0px 35px 35px;width:863px;height:283px;"]);

/***/ })

};
;