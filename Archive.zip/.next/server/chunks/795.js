"use strict";
exports.id = 795;
exports.ids = [795];
exports.modules = {

/***/ 9795:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_UpcomingProjectsCarousel)
});

// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__(8130);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(8308);
;// CONCATENATED MODULE: ./components/UpcomingProjectsCarousel.Styles.js

/* harmony default export */ const UpcomingProjectsCarousel_Styles = ((0,styles_.makeStyles)(({
  breakpoints
}) => ({
  mainFeatureBox: {
    marginTop: 10,
    borderColor: 'black',
    borderWidth: 1
  },
  image: {
    maxHeight: 221,
    maxWidth: 221
  },
  row: {
    display: 'flex',
    flexDirection: 'row'
  }
})));
// EXTERNAL MODULE: external "@mui/icons-material"
var icons_material_ = __webpack_require__(7915);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/UpcomingProjectsCarousel.js








const UpcomingProjectsCarousel = () => {
  const classes = UpcomingProjectsCarousel_Styles();
  const {
    0: details,
    1: setDetails
  } = (0,external_react_.useState)([{
    title: 'SwipeXYZ (upcoming)',
    details: 'Similique quis a libero enim quod corporis saepe quis. Perspiciatis velit quae consectetur consequatur eligendi. Omnis officiis quis culpa possimus exercitationem nesciunt commodi mollitia. Aut eum in est. In facere non. Corporis cumque sapiente deleniti placeat magnam sunt excepturi est sit.',
    img1: '/carousel1.png',
    img2: '/carousel2.png'
  }, {
    title: 'SwipeXYZ 2(upcoming)',
    details: 'Similique quis a libero enim quod corporis saepe quis. Perspiciatis velit quae consectetur consequatur eligendi. Omnis officiis quis culpa possimus exercitationem nesciunt commodi mollitia. Aut eum in est. In facere non. Corporis cumque sapiente deleniti placeat magnam sunt excepturi est sit.',
    img1: '/carousel2.png',
    img2: '/carousel1.png'
  }, {
    title: 'SwipeXYZ3 (upcoming)',
    details: 'Similique quis a libero enim quod corporis saepe quis. Perspiciatis velit quae consectetur consequatur eligendi. Omnis officiis quis culpa possimus exercitationem nesciunt commodi mollitia. Aut eum in est. In facere non. Corporis cumque sapiente deleniti placeat magnam sunt excepturi est sit.',
    img1: '/carousel1.png',
    img2: '/carousel2.png'
  }]);
  const {
    0: position,
    1: setPosition
  } = (0,external_react_.useState)(0);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "columns",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "column is-half",
      children: [/*#__PURE__*/jsx_runtime_.jsx(core_.Typography, {
        variant: "h2",
        children: details[position].title
      }), /*#__PURE__*/jsx_runtime_.jsx(core_.Typography, {
        variant: "p",
        children: details[position].details
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "column is-1"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: classes.row,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
        onClick: () => position !== 0 ? setPosition(position - 1) : setPosition(2),
        sx: {
          color: '#C6C6C6'
        },
        "aria-label": "upload picture",
        component: "span",
        children: /*#__PURE__*/jsx_runtime_.jsx(icons_material_.ArrowBackIos, {
          sx: {
            color: '#C6C6C6'
          }
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("img", {
        className: `column ${classes.image}`,
        src: details[position].img1,
        height: "20px"
      }), /*#__PURE__*/jsx_runtime_.jsx("img", {
        className: `column ${classes.image}`,
        src: details[position].img2
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
        "aria-label": "upload picture",
        component: "span",
        onClick: () => position !== 2 ? setPosition(position + 1) : setPosition(0),
        children: /*#__PURE__*/jsx_runtime_.jsx(icons_material_.ArrowForwardIos, {
          sx: {
            color: '#C6C6C6'
          }
        })
      })]
    })]
  });
};

/* harmony default export */ const components_UpcomingProjectsCarousel = (UpcomingProjectsCarousel);

/***/ })

};
;