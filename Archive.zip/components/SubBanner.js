import React from 'react'

export const SubBanner = () => {
  return (
    <section className="hero is-medium is-link has-text-centered">
        <div className="hero-body subpagebanner-body Home_subpagebanner-body__zGm2F">
            <p className="title">
             Contact Us
            </p>
            <p className='subtitle'>
                Home &gt; Contact Us
            </p>
            
        </div>
    </section>
  )
}
